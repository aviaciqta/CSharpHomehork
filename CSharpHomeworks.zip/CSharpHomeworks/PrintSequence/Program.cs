﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrintSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("2");
            Console.WriteLine("-3");
            Console.WriteLine("4");
            Console.WriteLine("-5");
            Console.WriteLine("6");
            Console.WriteLine("-7");
            Console.WriteLine("8");
            Console.WriteLine("-9");
            Console.WriteLine("10");
            Console.WriteLine("-11");
        }
    }
}
